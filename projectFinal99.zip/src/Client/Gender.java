package Client;

public enum Gender {
    Male,Female,Not_Say;

}
